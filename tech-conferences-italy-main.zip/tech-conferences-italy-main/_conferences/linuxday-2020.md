---
name: "Linux Day 2020"
website: https://www.linuxday.it/2020/
online: true

date_start: 2020-10-24
date_end:   2020-10-25

cfp_start: 2020-05-01
cfp_end:   2020-07-31
cfp_site:  https://www.linuxday.it/2020/partecipa/

---
