---
name: "Incontro DevOps - Settembre 2021"
website: https://www.eventbrite.com/e/biglietti-idi-incontro-devops-italia-2021-140265813825
location: Online
online: true

date_start: 2021-09-28
date_end:   2021-09-28
---
