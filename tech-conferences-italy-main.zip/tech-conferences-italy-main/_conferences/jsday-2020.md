---
name: "JsDay"
website: https://2020.jsday.it/index.html
location: Verona, Italy
online: true

date_start: 2020-09-10
date_end:   2020-09-11
---
