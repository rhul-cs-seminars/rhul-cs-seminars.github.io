---
name: "Come To Code"
website: https://www.cometocode.it/
location: Pignola (Potenza), Italy
online: false

date_start: 2023-09-22
date_end:   2023-09-24

cfp_start: 2023-01-12
cfp_end:   2023-04-30
cfp_site:  https://www.cometocode.it/call_for_speaker.html
---
