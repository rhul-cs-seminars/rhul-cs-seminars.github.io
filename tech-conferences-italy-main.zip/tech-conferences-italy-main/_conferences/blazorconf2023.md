---
name: "Blazor Conf 2023"
website: https://blazorconf.it/
location: Milan, Italy - Online
online: true

date_start: 2023-05-26
date_end:   2023-05-26
---