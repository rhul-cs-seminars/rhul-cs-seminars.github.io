---
name: "vueday"
website: https://2021.vueday.it/
location: Italy
online: true

date_start: 2021-04-29
date_end:   2021-04-29

cfp_start: 2021-01-01
cfp_end:   2021-02-28
cfp_site:  https://2021.vueday.it/welcome/cfp.html
---
