---
name: "Codemotion"
website: https://events.codemotion.com/conferences/online/2021/online-tech-conference-italian-edition-spring
location: Online
online: true

date_start: 2021-03-23
date_end:   2021-03-25

cfp_start: 2020-12-17
cfp_end:   2021-01-29
cfp_site:  https://extra.codemotion.com/onlineconf-italian-2021-cfp
---
