---
name: "Incontro DevOps"
website: https://www.eventbrite.com/e/biglietti-idi-incontro-devops-italia-2021-140265813825
location: Online
online: true

date_start: 2021-07-02
date_end:   2021-07-02
---
