---
name: "Kubernetes Community Days Italy 2023"
website: https://community.cncf.io/events/details/cncf-kcd-italy-presents-kubernetes-community-days-italy-2023/
location: Milano, Italy

date_start: 2023-06-16
date_end:   2023-06-16

cfp_start: 2023-01-11
cfp_end:   2023-02-26
cfp_site:  https://community.cncf.io/events/details/cncf-kcd-italy-presents-kubernetes-community-days-italy-2023/
---
