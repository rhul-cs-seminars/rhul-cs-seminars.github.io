---
name: "GDG DevFest"
website: https://devfest.gdgpisa.it/
location: Pisa, Italy

date_start: 2023-04-01
date_end:   2023-04-01

cfp:
  start: 2022-10-26
  end:   2023-01-31
  site:  https://sessionize.com/devfest-pisa-2023
---