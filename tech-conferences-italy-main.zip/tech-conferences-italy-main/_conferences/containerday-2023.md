---
name: "containerday"
website: https://2023.containerday.it/
location: Bologna

date_start: 2023-10-12
date_end:   2023-10-12

cfp_start: 2023-01-01
cfp_end:   2023-06-25
cfp_site:  https://2023.containerday.it/welcome/cfp.html
---
