---
name: "containerday"
website: https://2022.containerday.it/
location: Bologna

date_start: 2022-10-27
date_end:   2022-10-28
---
