---
name: "CSS Day 2023"
website: https://community.codemotion.com/grusp/meetups/cssday-1/
location: Faenza

date_start: 2023-03-31
date_end:   2023-03-31

---