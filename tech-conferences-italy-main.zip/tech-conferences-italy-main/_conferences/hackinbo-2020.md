---
name: "HackInBo"
website: https://www.hackinbo.it/
location: Bologna, Italy
online: true

date_start: 2020-10-31
date_end:   2020-10-31
---
