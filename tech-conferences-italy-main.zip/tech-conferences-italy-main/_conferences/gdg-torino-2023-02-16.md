---
name: "Flutter-Fire: sviluppa una app in un battito d'ali!"
website: https://www.eventbrite.it/e/biglietti-flutter-fire-sviluppa-una-app-in-un-battito-dali-529291694707
location: Torino

meetup: true

date_start: 2023-02-16
date_end:   2023-02-16
---