---
name: "Voxxed Days"
website: https://voxxeddays.com/milan/
location: Milano, Italy
status: Canceled

date_start: 2020-09-26
date_end:   2020-09-26
---
