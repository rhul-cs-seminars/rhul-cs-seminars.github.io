---
name: "Azure Day 2022"
website: https://www.azureday.it/
location: Rome, Italy - Online
online: true

date_start: 2022-06-24
date_end: 2022-06-24
---
