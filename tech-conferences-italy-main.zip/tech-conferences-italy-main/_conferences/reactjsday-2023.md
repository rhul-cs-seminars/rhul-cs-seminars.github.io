---
name: "Reactjsday"
website: https://2023.reactjsday.it/
location: Verona

date_start: 2023-10-27
date_end:   2023-10-27

cfp_start: 2023-01-01
cfp_end:   2023-08-15
cfp_site:  https://2023.reactjsday.it/welcome/cfp.html
---
