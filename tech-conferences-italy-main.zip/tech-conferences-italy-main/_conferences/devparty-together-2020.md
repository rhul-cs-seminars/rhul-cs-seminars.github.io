---
name: "GDG DevParty Together"
website: https://www.gdgdevparty.it/
location: Online
online: true

date_start: 2020-05-02
date_end:   2020-05-03

cfp_start: 2020-04-07
cfp_end:   2020-04-22
cfp_site:  https://sessionize.com/devfest-together/
---
