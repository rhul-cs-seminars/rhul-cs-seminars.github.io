---
name: "Blazor Conf"
website: https://blazorconf.it/
location: Rome, Italy - Online
online: true

date_start: 2022-05-27
date_end: 2022-05-27
---
