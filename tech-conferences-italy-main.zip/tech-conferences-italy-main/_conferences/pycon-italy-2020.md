---
name: "Pycon IT (11)"
website: https://pycon.it/en/
location: Florence, Italy
status: Canceled

date_start: 2020-11-05
date_end:   2020-11-08

cfp_start: 2019-12-05
cfp_end:   2020-01-06
cfp_site:  https://pycon.it/en/call-for-proposals/
---
