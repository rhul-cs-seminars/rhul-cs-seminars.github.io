---
name: "Droidcon"
website: http://it.droidcon.com/2017/
location: Turin, IT

date_start: 2017-04-06
date_end:   2017-04-07

cfp_start: 2016-10-14
cfp_end:   2017-01-31
cfp_site: http://it.droidcon.com/2017/call-for-papers-droidon-italy/
---
