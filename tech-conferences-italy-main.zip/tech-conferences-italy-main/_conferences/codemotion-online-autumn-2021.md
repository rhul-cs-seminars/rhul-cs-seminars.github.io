---
name: "Codemotion"
website: https://events.codemotion.com/conferences/online/2021/online-tech-conference-italian-edition-autumn/
location: Online
online: true

date_start: 2021-11-09
date_end:   2021-11-11

cfp_start: 2021-05-01
cfp_end:   2021-07-09
cfp_site:  https://extra.codemotion.com/onlineconf21-autumn-cfp/
---
