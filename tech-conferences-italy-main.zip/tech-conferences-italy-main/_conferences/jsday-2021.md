---
name: "JsDay"
website: https://2021.jsday.it/index.html
location: Online
online: true

date_start: 2020-07-06
date_end:   2020-07-07
---
