---
name: "Golab"
website: https://golab.io/
location: Prato, Italy

date_start: 2022-10-02
date_end:   2022-10-04

cfp_start: 2022-05-01
cfp_end:   2022-06-12
cfp_site: https://www.papercall.io/golab2022
---
