---
name: "uxday"
website: https://2023.uxday.it/
location: Faenza, Italy

date_start: 2023-09-29
date_end:   2023-09-29
---
