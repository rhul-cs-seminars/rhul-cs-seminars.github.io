---
name: "CyberSec 2023"
website: https://www.cybersecitalia.events
location: Roma

date_start: 2023-03-01
date_end:   2023-03-02

---