---
name: "devsecopsday 2023"
website: https://2023.devsecopsday.it/
location: Bologna, Italy

date_start: 2023-10-13
date_end:   2023-10-13

cfp_start: 2023-01-01
cfp_end:   2023-06-25
cfp_site:  https://2023.devsecopsday.it/welcome/cfp.html
---