---
name: "JsDay"
website: https://jsday.it/
location: Verona

date_start: 2022-04-21
date_end:   2022-04-22

cfp_start: 2022-01-01
cfp_end:   2022-02-01
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLScwv7c7Mi-FA-q6s7_ckcxiHpxQrnjycHw2ahNJv7YOuPff4Q/viewform
---
