---
name: "GDG DevFest"
website: http://devfestlevante.eu/
location: Levante, Italy

date_start: 2018-08-25
date_end:   2018-09-01
---
