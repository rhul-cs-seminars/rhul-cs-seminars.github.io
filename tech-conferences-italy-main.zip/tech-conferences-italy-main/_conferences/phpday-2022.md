---
name: "phpday"
website: https://phpday.it/
location: Verona

date_start: 2022-05-19
date_end:   2022-05-20

cfp_start: 2022-01-01
cfp_end:   2022-02-01
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSdTVD8Ijdg964oeTroWw6NLf2TVPOibtXKQ5HzEdM1UVnM-4A/viewform
---
