---
name: "Droidcon"
website: https://it.droidcon.com/2021/
location: Turin, Italy
online: true

date_start: 2021-11-11
date_end:   2021-11-12

cfp_start: 2021-05-19
cfp_end:   2021-08-08
cfp_site: https://sessionize.com/droidcon-italy-2021/
---
