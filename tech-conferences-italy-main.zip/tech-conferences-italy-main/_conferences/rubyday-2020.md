---
name: "RubyDay"
website: https://2020.rubyday.it/
location: Verona, Italy
online: true

date_start: 2020-09-16
date_end:   2020-09-16
---
