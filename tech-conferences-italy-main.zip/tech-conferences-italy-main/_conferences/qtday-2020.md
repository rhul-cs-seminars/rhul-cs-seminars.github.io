---
name: "QtDay"
website: https://www.qtday.it/
location: Florence, Italy
online: true

date_start: 2020-11-16
date_end:   2020-11-21

cfp_start: 2020-07-27
cfp_end:   2020-08-30
cfp_site:  https://www.papercall.io/qtday2020
---
