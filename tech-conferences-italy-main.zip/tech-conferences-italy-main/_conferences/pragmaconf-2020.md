---
name: "Pragmaconf"
website: https://www.pragmaconference.com/
location: Bologna, Italy
online: true

date_start: 2020-10-08
date_end:   2020-10-09

cfp_start: 2020-01-01
cfp_end:   2020-06-30
cfp_site: https://docs.google.com/forms/d/e/1FAIpQLSd24Hp5KRDiaLkOh7kGkjQHol88cz-7ruRt--3nqumWoOVgow/viewform
---
