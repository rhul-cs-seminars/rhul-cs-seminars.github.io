---
name: "Swift Heroes Digital"
website: https://swiftheroes.com/2020/
location: Online
online: true

date_start: 2020-10-01
date_end:   2020-10-02

cfp_start: 2020-08-05
cfp_end:   2020-09-07
cfp_site: https://sessionize.com/swift-heroes-digital
---
