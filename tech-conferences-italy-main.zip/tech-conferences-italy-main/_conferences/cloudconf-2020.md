---
name: "CloudConf"
website: https://2020.cloudconf.it/
location: Turin, Italy
online: true

date_start: 2020-11-05
date_end:   2020-11-05
---
