---
name: "Merge-it 2023"
website: https://merge-it.net/
location: Verona, Italy
online: false

date_start: 2023-05-12
date_end:   2023-05-13

cfp_start: 2022-11-14
cfp_end:   2022-12-31
cfp_site:  https://merge-it.net/
---
