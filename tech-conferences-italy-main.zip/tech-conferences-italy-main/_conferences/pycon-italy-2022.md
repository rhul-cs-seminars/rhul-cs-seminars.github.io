---
name: "Pycon IT (12)"
website: https://pycon.it/en/
location: Florence, Italy

date_start: 2022-06-02
date_end:   2022-06-05
---
