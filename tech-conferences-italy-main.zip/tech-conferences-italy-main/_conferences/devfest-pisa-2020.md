---
name: "GDG DevFest"
website: https://devfest.gdgpisa.it/
location: Pisa, Italy
status: Postponed

date_start: 2020-04-18
date_end:   2020-04-19

cfp_start: 2020-01-15
cfp_end:   2020-02-17
cfp_site:  https://sessionize.com/devfest-pisa-2020
---
