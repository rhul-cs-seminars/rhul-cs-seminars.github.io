---
name: "CssDay"
website: https://2021.cssday.it/
location: Faenza, Italy
online: true

date_start: 2021-03-11
date_end:   2021-03-11

cfp_start: 2021-01-22
cfp_end:   2021-01-31
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSdQT6wlXlU_3lHlOeaAHMR6uG3m6bmb_B4r-M2ZKi2yUd5Cmg/viewform
---
