---
name: "Agile People Day"
website: https://www.agilepeopleday.com/
location: Bologna, Italy
stauts: Virtual Only

date_start: 2020-04-18
date_end:   2020-04-18
---
