---
name: "Incontro DevOps"
website: https://2020.incontrodevops.it/
location: Bologna, Italy
online: true

date_start: 2020-10-22
date_end:   2020-10-22
---
