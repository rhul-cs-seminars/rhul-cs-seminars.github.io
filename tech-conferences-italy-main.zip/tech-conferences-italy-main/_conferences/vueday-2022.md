---
name: "vueday"
website: https://2022.vueday.it/
location: Verona
online: true

date_start: 2022-09-30
date_end:   2022-09-30
---
