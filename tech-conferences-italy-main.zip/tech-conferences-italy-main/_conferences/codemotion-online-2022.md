---
name: "Codemotion Online Tech Conference 2022"
website: https://events.codemotion.com/conferences/online/2022/online-tech-conference-2022-italian-edition-spring
location: Online
online: true

date_start: 2022-03-23
date_end:   2022-03-24
---
