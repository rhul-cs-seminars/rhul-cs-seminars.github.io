---
name: "COBOLDay"
website: https://2020.cobolday.it/
location: Verona, Italy

date_start: 2020-04-01
date_end:   2020-04-01

cfp_start: 2020-01-15
cfp_end:   2020-02-28
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSdlAPVgpkAPcHvWA-E117MXSKSVC1VA_uECnM0oGa0s5vmQ6g/viewform
---
