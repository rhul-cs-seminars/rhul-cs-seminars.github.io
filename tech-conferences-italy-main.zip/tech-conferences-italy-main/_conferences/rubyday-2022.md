---
name: "RubyDay"
website: https://rubyday.it/
location: Verona, Italy
online: true

date_start: 2022-10-21
date_end:   2022-10-21
---
