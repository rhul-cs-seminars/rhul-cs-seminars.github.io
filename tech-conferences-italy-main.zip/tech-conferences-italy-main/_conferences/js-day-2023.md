---
name: "JS Day 2023"
website: https://2023.jsday.it/
location: Verona

date_start: 2023-04-13
date_end:   2023-04-14

cfp_start: 2022-11-04
cfp_end:   2023-01-31
cfp_site:  https://2023.jsday.it/welcome/cfp.html
---