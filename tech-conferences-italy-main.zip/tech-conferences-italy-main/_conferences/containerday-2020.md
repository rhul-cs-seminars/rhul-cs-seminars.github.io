---
name: "containerday"
website: https://2020.containerday.it/
location: Bologna, Italy
online: true

date_start: 2020-10-23
date_end:   2020-10-23

cfp_start: 2020-01-15
cfp_end:   2020-08-31
cfp_site:  https://forms.gle/tGyGBhATWNhVoVd76
---
