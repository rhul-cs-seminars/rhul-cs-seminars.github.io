---
name: "RomHack 2023"
website: https://romhack.io/
location: Roma

date_start: 2023-09-16
date_end:   2023-09-16

cfp_start: 2022-02-01 
cfp_end:   2023-05-28  
cfp_site: https://romhack.io/call-for-papers/
---
