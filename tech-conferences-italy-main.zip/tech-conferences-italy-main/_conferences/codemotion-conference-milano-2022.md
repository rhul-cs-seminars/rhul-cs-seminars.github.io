---
name: "Codemotion Conference 2022"
website: https://extra.codemotion.com/conference-milan-2022/
location: Milano, Italy
online: false

date_start: 2022-10-18
date_end:   2022-10-19

cfp_start: 2022-06-06
cfp_end:   2022-07-08
cfp_site:  https://extra.codemotion.com/conferencemilan2022-cfp/
---
