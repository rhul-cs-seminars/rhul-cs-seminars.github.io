---
name: "Agile venture"
website: https://agilemovement.it/venture/2020/vimercate/
location: Vimercate, Italy
online: true

date_start: 2020-05-30
date_end:   2020-05-30

cfp_start: 2020-03-05
cfp_end:   2020-04-12
cfp_site:  https://sessionize.com/agile-venture-vimercate-2020/
---
