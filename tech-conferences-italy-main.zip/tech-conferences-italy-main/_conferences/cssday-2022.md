---
name: "CssDay"
website: https://www.eventbrite.it/e/biglietti-cssday-2022-204297227507
location: Faenza, Italy

date_start: 2022-04-01
date_end:   2022-04-01

cfp_start: 2021-11-01
cfp_end:   2022-01-06
cfp_site:  https://grusp.org/CFPcssday
---
