---
name: "GoLab"
website: https://golab.io/
location: Florence, Italy
online: false

date_start: 2023-11-19
date_end:   2023-11-21

cfp_start: 2023-04-19
cfp_end:   2023-05-21
cfp_site: https://www.papercall.io/golab2023
---
