---
name: "vueday"
website: https://2023.vueday.it/
location: Verona

date_start: 2023-11-10
date_end:   2023-11-10

cfp_start: 2023-06-01
cfp_end:   2023-08-31
cfp_site:  https://2023.vueday.it/welcome/cfp.html
---
