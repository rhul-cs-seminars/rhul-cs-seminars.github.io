---
name: "AngularDay"
website: https://2020.angularday.it/
location: Verona, Italy

date_start: 2020-06-11
date_end:   2020-06-12
---
