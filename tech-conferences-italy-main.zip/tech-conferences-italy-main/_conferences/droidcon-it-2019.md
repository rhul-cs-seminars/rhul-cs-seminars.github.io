---
name: "Droidcon"
website: http://it.droidcon.com/2019/
location: Turin, IT

date_start: 2019-04-04
date_end:   2019-04-05
cfp_start: 2018-12-03
cfp_end: 2019-01-10
cfp_site: https://www.syx.it/cfp/en/droidcon/droidcon-turin-2019
---
