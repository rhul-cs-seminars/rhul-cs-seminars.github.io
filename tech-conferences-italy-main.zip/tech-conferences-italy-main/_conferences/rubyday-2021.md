---
name: "RubyDay"
website: https://2021.rubyday.it/
location: Verona, Italy
online: true

date_start: 2021-04-07
date_end:   2021-04-07

cfp_start: 2021-01-22
cfp_end:   2021-02-15
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSf7g5GzZgJYWujfWxuEtga8cW5S1W9o6N9PrRk9zd8VJe8zJQ/viewform
---
