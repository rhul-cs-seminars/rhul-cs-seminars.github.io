---
name: "Workshop Fest Codemotion"
website: https://events.codemotion.com/conferences/online/2022/workshop-fest
location: Online
online: true

date_start: 2022-05-24
date_end:   2022-05-25
---
