---
name: "Codemotion Conference 2023"
website: https://extra.codemotion.com/conference-milan-2023/
location: Milano, Italy
online: false

date_start: 2023-10-24
date_end:   2023-10-25

cfp_start: 2023-04-21
cfp_end:   2023-07-01
cfp_site:  https://sessionize.com/codemotion-milan-2023/
---
