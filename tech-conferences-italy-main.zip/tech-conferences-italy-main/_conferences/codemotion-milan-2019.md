---
name: "Codemotion"
website: https://events.codemotion.com/conferences/milan/2019/
location: Milan, Italy

date_start: 2019-10-24
date_end:   2019-10-25

cfp_start: 2019-03-16  # Optional
cfp_end:   2019-04-24  # Optional
cfp_site: https://events.codemotion.com/conferences/milan/2019/call-for-papers-guidelines/
---
