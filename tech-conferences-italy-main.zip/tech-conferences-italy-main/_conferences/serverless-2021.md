---
name: "Serverless @localhost"
website: https://www.eventbrite.it/e/biglietti-serverless-127001-155658479703
location: Online
online: true

date_start: 2021-06-29
date_end:   2021-06-29
---
