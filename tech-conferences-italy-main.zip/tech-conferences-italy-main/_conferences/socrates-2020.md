---
name: "SoCraTes IT"
website: http://www.socrates-conference.it/
location: Dimaro (TN), Italy
status: Cancelled

date_start: 2020-06-04
date_end:   2020-06-06
---
