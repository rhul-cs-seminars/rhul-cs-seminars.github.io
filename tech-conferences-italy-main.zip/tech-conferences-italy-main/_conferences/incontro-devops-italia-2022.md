---
name: "Incontro DevOps Italia 2022"
website: https://incontrodevops.it/
location: Bologna, Italy

date_start: 2022-03-18
date_end:   2022-03-18

cfp_start: 2021-11-01
cfp_end:   2022-01-06
cfp_site:  https://grusp.org/CFPIDI
---