---
name: "Droidcon EMEA"
website: https://www.online.droidcon.com/emea2020
location: Online
online: true

date_start: 2020-10-08
date_end:   2020-10-09

cfp_start: 2020-07-25
cfp_end:   2020-08-30
cfp_site: https://sessionize.com/droidconEMEA/
---
