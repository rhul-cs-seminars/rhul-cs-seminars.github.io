---
name: "sfday"
website: https://2020.sfday.it
location: Verona, Italy
online: true

date_start: 2020-11-20
date_end:   2020-11-20

cfp_start: 2020-03-15
cfp_end:   2020-10-01
cfp_site:  https://forms.gle/UQDi8twBvn5vKh418
---
