---
name: "Devfest Alps 2022"
website: https://gdg.community.dev/events/details/google-gdg-valle-daosta-presents-devfest-alps-2022/
location: Torino, Italy
online: false

date_start: 2023-01-14
date_end: 2023-01-14
---
