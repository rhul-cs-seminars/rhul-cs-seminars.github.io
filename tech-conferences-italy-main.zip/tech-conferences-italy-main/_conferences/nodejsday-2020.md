---
name: "nodejsday"
website: https://2020.nodejsday.it/
location: Verona, Italy
online: true

date_start: 2020-10-02
date_end:   2020-10-02

cfp_start: 2020-03-15
cfp_end:   2020-09-01
cfp_site:  https://forms.gle/qMCJKqHMAgqdsqxz6
---
