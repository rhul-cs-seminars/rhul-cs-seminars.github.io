---
name: ".NET Conference 2023"
website: https://www.dotnetconf.it
location: Roma

date_start: 2023-03-10
date_end:   2023-03-10
---