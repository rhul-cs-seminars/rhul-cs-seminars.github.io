---
name: "Codemotion"
website: https://events.codemotion.com/conferences/online/2020/codemotion-online-tech-conference/
location: Online
online: true

date_start: 2020-10-20
date_end:   2020-10-24
---
