---
name: "AngularDay"
website: https://2023.angularday.it/
location: Verona, Italy

date_start: 2023-11-24
date_end:   2023-11-24

cfp_start: 2023-07-24
cfp_end:   2023-08-31
cfp_site:  https://2023.angularday.it/welcome/cfp.html
---
