---
name: "Droidcon"
website: https://it.droidcon.com/2020/
location: Turin, Italy
online: true

date_start: 2020-11-27
date_end:   2020-11-28

cfp_start: 2019-12-10
cfp_end:   2020-01-20
cfp_site: https://sessionize.com/droidcon-italy/
---
