---
name: "Web Day 2023"
website: https://www.webdayconf.it
location: Milan, Italy
online: false

date_start: 2023-03-16
date_end:   2023-03-16

cfp_start: 2022-11-14
cfp_end:   2022-12-31
cfp_site:  https://sessionize.com/web-day-2023
---
