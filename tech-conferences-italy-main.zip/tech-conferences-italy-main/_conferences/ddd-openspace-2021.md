---
name: "DDD OpenSpace 2021"
website: https://www.eventbrite.it/e/biglietti-ddd-open-space-2021-133228842053
location: Online
online: true

date_start: 2021-03-05
date_end:   2021-03-06
---
