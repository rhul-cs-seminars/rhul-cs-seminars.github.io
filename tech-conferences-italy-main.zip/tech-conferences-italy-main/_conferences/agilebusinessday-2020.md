---
name: "Agile Business Day"
website: https://www.agilebusinessday.com/
location: Venice, Italy
online: true

date_start: 2020-09-12
date_end:   2020-09-12
---
