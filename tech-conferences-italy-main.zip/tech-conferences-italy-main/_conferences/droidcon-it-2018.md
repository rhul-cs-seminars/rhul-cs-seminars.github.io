---
name: "Droidcon"
website: http://it.droidcon.com/2018/
location: Turin, IT

date_start: 2018-04-19
date_end:   2018-04-20

cfp_start: 2017-12-05
cfp_end: 2018-02-04
cfp_site: http://it.droidcon.com/2018/agenda/call-for-papers/
---
