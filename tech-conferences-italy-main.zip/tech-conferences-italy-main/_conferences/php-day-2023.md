---
name: "PHP Day 2023"
website: https://community.codemotion.com/grusp/meetups/phpday-2023/
location: Verona

date_start: 2023-05-18
date_end:   2023-05-19

---