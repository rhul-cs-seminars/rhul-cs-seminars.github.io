---
name: "Droidcon"
website: http://it.droidcon.com/2016/
location: Turin, IT

date_start: 2016-04-07
date_end:   2016-04-08

cfp_start: 2015-09-01  # Optional
cfp_end:   2016-01-31  # Optional
cfp_site: http://it.droidcon.com/2016/call-for-paper/ # Optional, will default to website
---
