---
name: "laravelday"
website: https://2020.laravelday.it/
location: Verona, Italy
online: true

date_start: 2020-11-26
date_end:   2020-11-26

cfp_start: 2020-03-15
cfp_end:   2020-10-01
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSfML2XghcpXBFrWC9ptBMMFX7SDIr9LTHRhDetrDw9VJwUO2w/viewform
---
