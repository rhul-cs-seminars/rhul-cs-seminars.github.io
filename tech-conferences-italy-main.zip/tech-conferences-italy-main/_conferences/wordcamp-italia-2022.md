---
name: "WordCamp Italia 2022"
website: https://italia.wordcamp.org/2022/
location: Milano, Italia
online: false

date_start: 2022-11-11
date_end:   2022-11-12
---
