---
name: "CssDay"
website: https://2020.cssday.it/
location: Faenza, Italy
online: true

date_start: 2020-06-19
date_end:   2020-06-19
---
