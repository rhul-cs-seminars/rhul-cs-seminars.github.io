---
name: "containerday"
website: https://2021.containerday.it/
location: Online
online: true

date_start: 2021-10-10
date_end:   2021-10-10

cfp_start: 2021-07-15
cfp_end:   2021-07-31
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSfCSEUR2arZA8qKXGljxG6CscXEyBmJYqfeyAu8Vhd_in00aA/viewform
---
