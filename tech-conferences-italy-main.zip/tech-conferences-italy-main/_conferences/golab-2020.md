---
name: "Golab"
website: https://golab.io/
location: Florence, Italy
online: true

date_start: 2020-10-19
date_end:   2020-10-25

cfp_start: 2020-07-20
cfp_end:   2020-08-16
cfp_site: https://www.papercall.io/golab2020?utm_source=GoLab&utm_campaign=5f23748d46-golab-2020-cfp-blind-tickets&utm_medium=email&utm_term=0_128b444223-5f23748d46-365048793
---
