---
name: "HackInBo Business Edition 2023"
website: https://hackinbo.business/
location: Bologna, Italy
online: false

date_start: 2023-11-17
date_end:   2023-11-17
---
