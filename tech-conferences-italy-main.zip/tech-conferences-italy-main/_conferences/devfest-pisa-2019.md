---
name: "GDG DevFest"
website: https://2019.devfest.gdgpisa.it/
location: Pisa, Italy

date_start: 2019-04-13
date_end:   2019-04-13

cfp_start: 2018-12-27
cfp_end:   2019-02-05
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSdgEKpaxBBCCez1B79X4U4m0iCZDAygigEPbqu_guDCxQpnHA/viewform
---
