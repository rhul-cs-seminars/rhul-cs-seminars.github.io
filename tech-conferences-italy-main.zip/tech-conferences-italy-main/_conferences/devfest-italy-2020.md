---
name: "GDG DevFest Italy"
website: https://devfest.it/
location: Online
online: true

date_start: 2020-10-17
date_end:   2020-10-18
---
