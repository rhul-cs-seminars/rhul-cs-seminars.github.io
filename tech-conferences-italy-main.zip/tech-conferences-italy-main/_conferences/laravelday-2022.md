---
name: "laravelday"
website: https://2022.laravelday.it/
location: Verona
online: true

date_start: 2022-11-17
date_end:   2022-11-17
---
