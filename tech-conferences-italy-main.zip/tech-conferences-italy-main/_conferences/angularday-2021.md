---
name: "AngularDay"
website: https://2021.angularday.it/
location: Online
online: true

date_start: 2021-11-12
date_end:   2021-11-12
---
