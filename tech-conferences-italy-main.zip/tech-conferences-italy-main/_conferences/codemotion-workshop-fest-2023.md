---
name: "Codemotion Workshop Fest"
website: https://events.hubilo.com/workshop-fest-it-2023/register/

online: true

date_start: 2023-03-28
date_end:   2023-03-29

---