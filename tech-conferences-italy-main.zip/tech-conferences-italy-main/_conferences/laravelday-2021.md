---
name: "laravelday"
website: https://2021.laravelday.it/
location: Online
online: true

date_start: 2021-09-24
date_end:   2021-09-24

cfp_start: 2021-07-01
cfp_end:   2021-07-30
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSeF8nA0q-qPABFTg4zxdPIbBh3oV3Hh2c3WUVd3ye3kSJ62aA/viewform
---
