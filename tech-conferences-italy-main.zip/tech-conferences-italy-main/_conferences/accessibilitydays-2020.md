---
name: "Accessibility Days"
website: https://accessibilitydays.it/2020/
location: Milano, Italy
online: true

date_start: 2020-05-22
date_end:   2020-05-23

cfp_start: 2020-03-03
cfp_end:   2020-03-31
cfp_site:  https://sessionize.com/accessibility-days-2020

---
