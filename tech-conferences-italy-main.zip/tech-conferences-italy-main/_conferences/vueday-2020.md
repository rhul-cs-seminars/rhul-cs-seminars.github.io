---
name: "vueday"
website: https://2020.vueday.it/
location: Verona, Italy
online: true

date_start: 2020-09-15
date_end:   2020-09-15
---
