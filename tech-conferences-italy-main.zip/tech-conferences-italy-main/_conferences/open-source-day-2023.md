---
name: "Open Source Day 2023"
website: https://2023.osday.dev/
location: Florence, Italy

date_start: 2023-03-24
date_end:   2023-03-24

cfp_start: 2022-11-04
cfp_end:   2023-01-29
cfp_site:  https://sessionize.com/opensourceday23
---