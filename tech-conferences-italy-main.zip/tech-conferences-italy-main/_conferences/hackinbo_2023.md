---
name: "HackInBo 2023"
website: https://www.hackinbo.it/
location: Bologna, Italy
online: false

date_start: 2023-11-18
date_end:   2023-11-18
---
