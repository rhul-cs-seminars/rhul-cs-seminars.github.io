---
name: "Web Day"
website: https://www.ugidotnet.org/e/2840/Web-Day-2022
location: Online
online: true

date_start: 2022-03-10
date_end:   2022-03-10

cfp_start: 2021-11-29
cfp_end:   2022-01-08
cfp_site:  https://sessionize.com/web-day-2022/
---
