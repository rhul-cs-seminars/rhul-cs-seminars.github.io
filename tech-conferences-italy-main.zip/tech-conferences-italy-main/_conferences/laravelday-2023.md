---
name: "laravelday"
website: https://2023.laravelday.it/
location: Verona

date_start: 2023-11-09
date_end:   2023-11-09
---
