---
name: "Codemotion"
website: https://events.codemotion.com/conferences/online/2020/online-tech-conference-italian-edition/
location: Rome, Italy
online: true

date_start: 2020-11-24
date_end:   2020-11-26
---
