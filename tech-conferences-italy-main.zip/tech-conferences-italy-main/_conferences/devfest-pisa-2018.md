---
name: "GDG DevFest"
website: https://2018.devfest.gdgpisa.it/
location: Pisa, Italy

date_start: 2018-03-10
date_end:   2018-03-10

cfp_start: 2018-01-10
cfp_end:   2018-02-10
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSc_5Ldgb7XLhEr5kcbLPq3LV3La18vKH99Se3WYT_8vcePimA/viewform
---
