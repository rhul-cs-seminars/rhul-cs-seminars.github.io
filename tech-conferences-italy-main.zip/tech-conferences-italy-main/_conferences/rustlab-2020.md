---
name: "RustLab"
website: https://www.rustlab.it/
location: Florence, Italy
online: true

date_start: 2020-10-12
date_end:   2020-10-18

cfp_start: 2020-07-13
cfp_end:   2020-08-09
cfp_site:  https://www.rustlab.it/
---
