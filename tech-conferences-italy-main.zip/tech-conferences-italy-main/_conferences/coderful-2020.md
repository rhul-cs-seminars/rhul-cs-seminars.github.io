---
name: "Coderful"
website: https://www.coderful.io/
location: Catania, Italy
status: Postponed

date_start: 2020-06-06
date_end:   2020-06-06

cfp_start: 2020-01-15
cfp_end:   2020-02-28
cfp_site:  https://docs.google.com/forms/d/e/1FAIpQLSeAPORI9ex62U6XTskbsWZt_gJ4E6BIUrdbKMMfhebN2Ey4xQ/viewform
---
