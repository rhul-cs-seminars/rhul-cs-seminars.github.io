---
name: "Incontro DevOps - Ottobre 2021"
website: https://www.eventbrite.com/e/biglietti-idi-incontro-devops-italia-2021-140265813825
location: Online
online: true

date_start: 2021-10-28
date_end:   2021-10-28
---
